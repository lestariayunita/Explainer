# Kebakaran Kalimantan

Explainer ilustrasi vektor, gaya **Continuous action**, dibuat dengan Bang Motion v1.19.0 dari `assets/starter-explainer.html`.

- Durasi 15 detik, rasio 16:9, 1920×1080, 30 fps.
- Tanpa audio, sesuai brief yang disetujui.
- Satu mobil pemadam hadir sepanjang cerita: hutan mengering → penampang gambut dengan bara → tampak atas pemadaman dan pembasahan.
- Ilustrasi edukatif umum; tidak menggambarkan tanggal atau peristiwa kebakaran tertentu.

## Berkas

`kebakaran-kalimantan.mp4` adalah video H.264 untuk diputar atau dibagikan.

`index.html` adalah animasi yang bisa dibuka langsung di browser biasa. GSAP dan font telah ditanam dalam berkas; tidak memerlukan internet atau npm. Autoplay dan loop aktif. Space untuk pause/play, R untuk mengulang. Tambahkan `?debug=1` untuk panel scrub atau `?clean=1` untuk membekukan autoplay selama render.

`vo-script.md` berisi naskah narasi opsional. `build.py` membangun HTML dari rig starter dan aset yang telah dipasang di cloud ini.

## Arah visual

Palet turunan tema: hijau hutan #24584B, tanah gambut #543D32, krem berasap #E9E1CE, dan api #F27638. Archivo Black untuk judul dan Archivo untuk label. Ilustrasi flat berlapis, asap bergerak naik, strip hutan parallax, serta kamera turun mengikuti informasi bawah tanah. Asap melewati lensa untuk menyambungkan sudut samping dengan tampak atas.

## Konteks

Cerita menekankan sifat kebakaran pada gambut kering, yang dapat membara di bawah permukaan, dan pentingnya pemadaman serta pembasahan. Tidak ada angka luas kebakaran, korban, atau klaim kondisi terkini.

Bacaan latar: Page, S. E. et al. (2002), *The amount of carbon released from peat and forest fires in Indonesia during 1997*, Nature 420, 61–65. https://doi.org/10.1038/nature01131. Tautan ini adalah rujukan konteks umum, bukan sumber data kejadian terbaru; akses situs sumber tidak diambil ulang karena pembatasan jaringan cloud.

## Validasi

Tujuh frame kunci diperiksa secara visual. Pengujian browser memverifikasi durasi, ukuran panggung, scrub deterministik, loop autoplay, nol error JavaScript, dan nol request aset eksternal. Konten HTML mandiri diuji di halaman browser baru. Kebijakan Chromium cloud memblokir navigasi `file://`, sehingga pengujian cloud menggunakan server lokal dan konten tertanam.

Render final menggunakan `scripts/export-frames.mjs` dari Bang Motion, 450 frame pada 30 fps, lalu FFmpeg H.264/yuv420p. Frame render dan review disimpan terpisah dari paket hasil.

## Lisensi aset

Ilustrasi dibuat khusus dalam kode SVG. Bang Motion: MIT, Bang Tutorial. GSAP 3.12.5: standard license. Archivo dan Archivo Black: SIL Open Font License; lihat folder `licenses`.
