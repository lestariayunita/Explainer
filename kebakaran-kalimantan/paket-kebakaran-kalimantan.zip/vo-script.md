# Naskah narasi opsional — 15 detik

Video yang diserahkan tidak memiliki audio. Naskah ini dapat direkam untuk versi bernarasi.

**0–5 detik**

Saat hutan mengering, api mudah menyebar.

**5–10 detik**

Di Kalimantan, gambut kering bisa menyimpan bara di bawah permukaan.

**10–15 detik**

Padamkan api, basahi gambut, dan cegah pembakaran.

Bicara wajar, dengan jeda singkat antarbagian. Kirim rekaman WAV atau MP3 untuk menyinkronkan ulang animasi dengan suara.
