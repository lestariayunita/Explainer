# Lengket terus? — explainer kaki serangga

**Continuous action · 16:9 · 1080p · 30 fps · VO asli pengguna.** Durasi mengikuti audio, sekitar 38,84 detik; ujung video dibulatkan ke frame 30 fps terdekat.

Video dibangun dengan Bang Motion v1.19.0 dari rig `assets/starter-explainer.html`. Satu serangga hadir sepanjang cerita. Sepatu berlem menjadi hook, kamera mengikuti langkah, lensa makro menyingkap bantalan kaki, lalu sepatu kembali sebagai payoff penutup.

Teks layar hanya **“Lengket terus?”**, **“Menempel”**, dan **“Terlepas”**. Tanpa subtitle, judul bab, atau paragraf penjelasan. Klaim dan struktur narasi mengikuti VO yang disediakan; anatomi digambar sebagai ilustrasi mekanisme umum.

## Hasil

- `serangga-vo.mp4`: H.264/yuv420p dengan audio AAC dari VO asli.
- `index.html`: animasi dan audio mandiri; seluruh aset tertanam, tanpa npm atau internet.
- `vo-script.md`: transkrip kerja dan timing narasi.
- `poster.jpg`: frame untuk sampul.

Buka HTML di browser biasa. Audio dan visual mencoba autoplay bersama; jika browser memblokir audio, satu klik pada halaman memulai keduanya. Space untuk pause/play dan R untuk ulang. Panel scrub muncul hanya dengan `?debug=1`. `?clean=1` menghentikan autoplay untuk render.

## Style brief yang disetujui

Krem kaca #EFE8D8, hijau serangga #32534F, dan terracotta sepatu #D07748, diturunkan dari tema. Archivo Black + Archivo. Ilustrasi vektor berlapis pada permukaan kaca bergradasi, refleksi dan parallax yang bergerak pelan. Tanda tangan gerak: langkah dengan kontak dan lepas bergantian. Momen utama: pembesaran bantalan kaki pada kalimat mekanisme, diikuti gerak tarik dan menjauh.

## Validasi

Frame kunci telah diperiksa visual dan kontak kaki diperbaiki agar mengikuti kurva kaca. Browser memverifikasi scrub deterministik, timing label, pemutaran VO, sinkronisasi audio dengan timeline, restart loop, nol error JavaScript, serta nol permintaan aset eksternal. Durasi timeline dan metadata VO sama: 38,844063 detik.

Render menggunakan `export-frames.mjs` dari Bang Motion pada 30 fps, lalu FFmpeg untuk video dan audio. Ilustrasi, audio asli, dan font tertanam dalam HTML. `build.py` tersedia pada workspace untuk pengeditan; membutuhkan starter dan paket alat yang dipasang di cloud ini.

MP4 final telah didekode penuh tanpa error: 1920×1080, 30 fps, 1.165 frame, video 38,833333 detik, dan audio 38,843991 detik. Selisih durasi gambar terhadap VO kurang dari satu frame. Korelasi audio hasil encoding terhadap VO sumber adalah 0,999988.

## Aset dan lisensi

SVG digambar khusus untuk proyek. VO disediakan pengguna. Bang Motion: MIT, Bang Tutorial. Archivo dan Archivo Black: SIL Open Font License. GSAP 3.12.5: standard license. Berkas lisensi font dan Bang Motion disertakan dalam folder `licenses`.
