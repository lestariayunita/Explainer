# Transkrip kerja VO

Audio asli pengguna dipakai utuh. Transkrip ini dinormalisasi dari pengenalan suara untuk menyusun timing; bukan subtitle pada video.

| Rentang | Narasi |
|---|---|
| 0–3 dtk | Bayangkan kamu mengoleskan lem pada sepatumu. |
| 3–6,2 dtk | Mungkin akhirnya kamu bisa berjalan menaiki dinding. |
| 6,2–9,7 dtk | Tapi mengambil langkah berikutnya akan menjadi masalah. |
| 9,7–12,2 dtk | Serangga menghadapi persoalan serupa. |
| 12,2–16,7 dtk | Kakinya harus menempel, lalu terlepas berulang kali. |
| 17,05–21,65 dtk | Banyak serangga mengatasinya dengan bantalan perekat yang merespons gerakan. |
| 21,65–25,31 dtk | Tarik kaki ke arah tubuh dan bantalannya mencengkeram. |
| 25,31–28,35 dtk | Gerakan menjauh dan bantalannya terlepas. |
| 28,35–32,15 dtk | Jadi rahasianya bukan sekadar memiliki kaki lengket. |
| 32,15–35,15 dtk | Kakinya harus menempel pada saat yang tepat. |
| 35,15–38,84 dtk | Sepatu berlem perekatmu sepertinya membutuhkan fitur itu. |
