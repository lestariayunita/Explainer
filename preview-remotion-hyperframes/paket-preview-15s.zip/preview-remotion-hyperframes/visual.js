export const W=1920,H=1080,DURATION=15,FPS=30;
export const INK='#16263B',BONE='#F5F0E5',CORAL='#F26A3D',LIME='#BDEC6D',WATER='#60B6D0';
export const clamp=x=>Math.max(0,Math.min(1,x));
const smooth=x=>{x=clamp(x);return x*x*(3-2*x)};
const lerp=(a,b,t)=>a+(b-a)*t;
const enter=(t,a,d)=>1-Math.pow(1-clamp((t-a)/d),4);
const f=x=>Number(x.toFixed(3));
const tr=(x,y,s=1,r=0)=>`translate(${f(x)} ${f(y)}) rotate(${f(r)}) scale(${f(s)})`;
const path=(d,fill,stroke=INK,width=6,attrs='')=>`<path d="${d}" fill="${fill}" stroke="${stroke}" stroke-width="${width}" stroke-linecap="round" stroke-linejoin="round" ${attrs}/>`;
const oval=(x,y,rx,ry,fill,attrs='')=>`<ellipse cx="${f(x)}" cy="${f(y)}" rx="${rx}" ry="${ry}" fill="${fill}" ${attrs}/>`;
const limb=(ax,ay,bx,by,cx,cy,color)=>path(`M${ax} ${ay}L${f(bx)} ${f(by)}L${f(cx)} ${f(cy)}`,'none',INK,38)+path(`M${ax} ${ay}L${f(bx)} ${f(by)}L${f(cx)} ${f(cy)}`,'none',color,25);
const txt=(s,x,y,size,color=BONE)=>`<text x="${x}" y="${y}" fill="${color}" font-family="Fraunces" font-weight="900" font-size="${size}" letter-spacing="-5">${s}</text>`;
export function shotAt(t){return t<4.975?0:t<10.05?1:2}
export function wipeX(t,start,duration){return -3100+5020*(.5-.5*Math.cos(Math.PI*clamp((t-start)/duration)))}
export const defs=`<defs><radialGradient id="glass" cx="36%" cy="28%" r="74%"><stop stop-color="#BDE6E0" stop-opacity=".83"/><stop offset=".55" stop-color="#60B6D0" stop-opacity=".62"/><stop offset="1" stop-color="#20596F" stop-opacity=".94"/></radialGradient><radialGradient id="halo"><stop stop-color="#60B6D0" stop-opacity=".19"/><stop offset="1" stop-color="#60B6D0" stop-opacity="0"/></radialGradient><pattern id="wood" width="190" height="90" patternUnits="userSpaceOnUse"><path d="M0 30Q100 5 190 35M20 70Q110 95 160 65" fill="none" stroke="#F5F0E5" stroke-opacity=".12" stroke-width="3"/></pattern><clipPath id="dropMask"><circle cx="1410" cy="510" r="460"/></clipPath></defs>`;
function person(t,pose,scale=1,x=0,y=0,rotation=0){
 const crouch=pose==='land'?(1-smooth((t-5.25)/1.1))*.7:0;
 const walk=pose==='walk'?Math.sin((t-6.6)*9):0;
 const fall=pose==='fall',reach=pose==='reach'?smooth((t-11.25)/1.2):0;
 const shift=crouch*80-Math.abs(walk)*8;
 const fright=fall||reach>.5;
 let lfoot=[-44+walk*42,0],rfoot=[45-walk*42,-Math.max(0,walk)*22];
 if(fall){lfoot=[-91+Math.sin(t*3)*14,-11];rfoot=[93,-42+Math.sin(t*4)*21]}
 let lh=[-91-walk*20,-157],rh=[94+walk*20,-162];
 if(fall){lh=[-165,-348];rh=[141,-356+Math.sin(t*5)*15]}
 rh=[lerp(rh[0],181,reach),lerp(rh[1],-225+shift,reach)];
 const back=limb(-40,-246+shift,-87,-208+shift,...lh,CORAL)+oval(...lh,17,18,'#C58C68',`stroke="${INK}" stroke-width="5"`);
 const legs=limb(-32,-139+shift,-40+walk*21,-64+crouch*36,...lfoot,'#354C64')+limb(31,-139+shift,43-walk*22,-65+crouch*20,...rfoot,'#354C64')+`<g stroke="${INK}" stroke-width="6"><path d="M${f(lfoot[0]-18)} ${f(lfoot[1]-14)}h58q15 4 16 19h-73z" fill="${BONE}"/><path d="M${f(rfoot[0]-18)} ${f(rfoot[1]-14)}h58q15 4 16 19h-73z" fill="${BONE}"/></g>`;
 const body=`<g transform="translate(0 ${f(shift)})">${path('M-51-268Q-74-230-54-139Q0-121 56-139L61-252Q36-283-51-268Z',CORAL)}${path('M-51-253L-78-256Q-100-202-78-170L-55-174Z',LIME)}${path('M-19-259L-10-143','none',BONE,5)}${path('M20-209L50-205L45-180L16-184Z','#D94F31',INK,3)}${path('M-33-275L6-262L35-277L23-287L-18-291Z',LIME,INK,5)}
 <g>${oval(1,-324,52,62,'#C58C68',`stroke="${INK}" stroke-width="6"`)}${path('M-51-317Q-75-366-33-389Q-17-407 5-395Q31-409 48-379Q70-365 46-336L29-354L9-347L-5-369L-29-351L-32-313Z',INK)}${oval(-44,-320,14,18,'#C58C68',`stroke="${INK}" stroke-width="4"`)}${path('M44-330L67-308L43-299','#C58C68',INK,5)}${oval(23,-337,7,10,INK)}${path(fright?'M9-354L34-360':'M8-355Q23-364 35-354','none',INK,5)}${fright?oval(28,-286,10,13,INK):path('M10-285Q28-274 42-289','none',INK,5)}</g></g>`;
 const arm=limb(48,-252+shift,lerp(87,112,reach),lerp(-208,-225+shift,reach),...rh,CORAL)+oval(...rh,18,18,'#C58C68',`stroke="${INK}" stroke-width="5"`);
 return `<g transform="${tr(x,y,scale,rotation)}">${back}${legs}${body}${arm}</g>`;
}
function grass(x,y,s=1,color='#829389',phase=0){return `<g transform="${tr(x,y,s)}">${path(`M0 0Q-30-115 ${f(-52+Math.sin(phase)*10)}-180M18 0Q40-135 85-204M35 0Q68-50 120-62`,'none',color,13)}</g>`}
export function partsAt(t){
 t=Math.max(0,Math.min(15,t));let shot=shotAt(t),environment='',hero='',danger='',measure='';
 const bg=shot===1?BONE:INK;
 if(shot===0){
  environment=`${oval(1520,460,660,660,'#203850')}${path('M-100 101L787 139L804 209L-100 160Z','#466A7B',BONE,5)}${path('M717 200L775 203L778 1180L720 1180Z','#284658',WATER,4)}<path d="M-100 101L787 139L804 209L-100 160Z" fill="url(#wood)"/>`;
  for(let i=0;i<13;i++){let x=905+i*73,y=((t*290+i*172)%1300)-100;environment+=path(`M${x} ${f(y)}v${95+i%3*65}`,'none',BONE,2,`opacity="${.12+i%3*.05}"`)}
  hero=person(t,'fall',1.55,1220+Math.sin(t*2)*25,lerp(690,870,smooth(t/4.8)),-16+Math.sin(t*2.3)*10);
  measure=txt('200×',120,535,220,LIME)+path('M134 581H637','none',CORAL,14)+path('M200 720V915M180 889L200 917L220 889','none',BONE,7);
 }else if(shot===1){
  const u=smooth((t-6.5)/3.4),drift=u*270;
  environment=`${oval(1400,470,480,480,'#E1E7D3')}${oval(1450,460,352,352,'#ECEDD9')}${path('M0 925Q420 900 920 925Q1450 947 1920 922V1080H0Z',INK)}${path('M0 947Q420 924 900 947Q1450 969 1920 944','none',LIME,7)}`;
  for(let i=0;i<7;i++){let x=-100+i*370-drift*.5;environment+=grass(x,924,.8+i%2*.3,'#7F9385',t+i)}
  environment+=path('M1330 923L1430 855L1514 920Z','#A4B3AA',INK,4)+path('M100 1020Q400 977 690 1030Q1020 995 1500 1034','none','#35465A',7);
  hero=oval(960+u*140,927,177,24,'#0A1425','opacity=".34"')+person(t,t<6.65?'land':'walk',1.63,950+u*140,922,0);
  const impact=Math.max(0,1-(t-5.15)/.9);for(let i=0;i<7;i++){let x=830+i*58+(i-3)*90*(1-impact),y=914-(1-impact)*80*Math.sin(i);danger+=oval(x,y,5+impact*14,4+impact*5,CORAL,`opacity="${f(impact)}"`)}
 }else{
  const reach=smooth((t-11.25)/1.2),hx=600,hy=957,scale=1.55;
  const handLocalX=lerp(94,181,reach),handLocalY=lerp(-162,-225,reach),ang=-Math.PI/180;
  const handX=hx+(handLocalX*Math.cos(ang)-handLocalY*Math.sin(ang))*scale,handY=hy+(handLocalX*Math.sin(ang)+handLocalY*Math.cos(ang))*scale;
  environment=`${oval(1390,460,670,670,'url(#halo)')}${path('M0 963Q480 939 920 963Q1450 977 1920 963V1080H0Z','#203951')}${path('M0 964Q450 944 1920 962','none','#436175',6)}${grass(90,971,1.2,'#38556B',t)}${grass(1780,980,1.4,'#38556B',t)}`;
  danger=`${oval(1410,990,470,47,'#0A1425')}${oval(1410,510,460,460,'url(#glass)',`stroke="${WATER}" stroke-width="9"`)}${oval(1410,510,443,443,'none',`stroke="#A8DFDF" stroke-opacity=".27" stroke-width="3"`)}<g clip-path="url(#dropMask)" opacity=".09" transform="translate(2650 0) scale(-1 1)">${person(t,'reach',1.35,1170,985,0)}</g>${oval(1635,465,28,45,BONE,'opacity=".7"')}`;
  hero=person(t,'reach',scale,hx,hy,-1);
  if(reach>.05)danger+=path(`M988 580Q930 568 ${f(handX)} ${f(handY-18)}Q${f(handX-17)} ${f(handY+6)} ${f(handX)} ${f(handY+20)}Q951 660 997 655Z`,WATER,WATER,4,`opacity="${f(reach*.85)}"`);
  if(t>12.35)measure=txt('THIS?',100,210,96,BONE);
 }
 return {shot,bg,environment,hero,danger,measure};
}
export function entryAt(t,kind){const shot=shotAt(t),a=[.15,4.975,10.05][shot];if(kind==='environment')return {opacity:enter(t,a,.42),scale:1+(1-Math.sin(clamp((t-a)/.65)*Math.PI/2))*.035};if(kind==='hero')return {opacity:enter(t,a+.04,.22),x:(1-enter(t,a+.04,.36))*(shot===2?-60:40)};if(kind==='danger'){let u=clamp((t-a-.08)/.7)-1;return {opacity:enter(t,a+.08,.5),scale:1+.06*(2.70158*u*u*u+1.70158*u*u)}}let a2=shot===2?12.35:a+.16;return {opacity:enter(t,a2,.28),y:26*Math.pow(2,-10*clamp((t-a2)/.4))}}
export function glintAt(t){if(t<10.05)return '';let opacity=enter(t,10.05,.3);return `<g opacity="${f(opacity)}" transform="translate(${f(clamp((t-10.05)/4.95)*18)} 0)">${path('M1085 436Q1107 169 1399 111','none',BONE,27)}${path('M1087 492L1083 538','none',BONE,14)}</g>`}
export function svgAt(t,withWipes=true){const p=partsAt(t);let layers='';for(let key of ['environment','danger','hero','measure']){let a=entryAt(t,key);layers+=`<g opacity="${f(a.opacity)}" transform="translate(${f(a.x??0)} ${f(a.y??0)}) translate(960 540) scale(${f(a.scale??1)}) translate(-960 -540)">${p[key]}</g>`}let wipe='';if(withWipes)for(let [start,d] of [[4.65,.65],[9.75,.6]])if(t>=start&&t<=start+d){let x=wipeX(t,start,d);wipe+=`<g transform="translate(${f(x)} 0)">${path('M0 0H2800L3100 1080H300Z',LIME,'none',0)}${path('M0 0H130L430 1080H300Z',CORAL,'none',0)}</g>`}return `<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" viewBox="0 0 1920 1080">${defs}<rect width="1920" height="1080" fill="${p.bg}"/>${layers}${glintAt(t)}${wipe}</svg>`}
