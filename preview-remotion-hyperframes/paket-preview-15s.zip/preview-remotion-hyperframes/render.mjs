import fs from 'node:fs';import path from 'node:path';
import {bundle} from '@remotion/bundler';import {selectComposition,renderMedia,renderStill} from '@remotion/renderer';
const root=path.dirname(new URL(import.meta.url).pathname);fs.mkdirSync(path.join(root,'public'),{recursive:true});fs.copyFileSync(path.join(root,'assets/voiceover.wav'),path.join(root,'public/voiceover.wav'));
const serveUrl=await bundle({entryPoint:path.join(root,'remotion/index.jsx'),publicDir:path.join(root,'public'),outDir:path.join(root,'.render-bundle')});
const opts={serveUrl,id:'IndependentPreview',...(process.env.REMOTION_BROWSER_EXECUTABLE?{browserExecutable:process.env.REMOTION_BROWSER_EXECUTABLE}:{})};const composition=await selectComposition(opts);
fs.mkdirSync(path.join(root,'review'),{recursive:true});
for(const t of [1.2,6.5,13.5])await renderStill({...opts,composition,frame:Math.round(t*30),output:path.join(root,'review',`remotion-${t}.jpg`),imageFormat:'jpeg',jpegQuality:95});
let last=-1;await renderMedia({...opts,composition,codec:'h264',crf:19,pixelFormat:'yuv420p',audioCodec:'aac',audioBitrate:'192k',imageFormat:'jpeg',jpegQuality:95,concurrency:3,outputLocation:path.join(root,'preview-15s.mp4'),onProgress:p=>{let x=Math.floor(p.progress*100/10)*10;if(x!==last){console.log(`${x}%`);last=x}}});console.log('Preview complete: 450 frames');
