import React,{useEffect,useState} from 'react';
import {AbsoluteFill,Audio,Composition,continueRender,delayRender,registerRoot,staticFile,useCurrentFrame} from 'remotion';
import {svgAt,W,H,FPS,DURATION} from '../visual.js';
import './style.css';
function Preview(){const frame=useCurrentFrame();const [handle]=useState(()=>delayRender('Preview font'));useEffect(()=>{document.fonts.load('900 120px Fraunces').then(()=>continueRender(handle))},[handle]);return <AbsoluteFill style={{background:'#16263B'}}><div style={{width:W,height:H}} dangerouslySetInnerHTML={{__html:svgAt(frame/FPS)}}/><Audio src={staticFile('voiceover.wav')}/></AbsoluteFill>}
registerRoot(()=> <Composition id="IndependentPreview" component={Preview} width={W} height={H} fps={FPS} durationInFrames={DURATION*FPS}/>);
