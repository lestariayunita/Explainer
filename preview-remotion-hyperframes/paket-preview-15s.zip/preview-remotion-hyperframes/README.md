# Preview 15 detik — Remotion + HyperFrames + JavaScript

Versi desain baru berdasarkan 15 detik pembuka VO Inggris yang sebelumnya dikirim pengguna. Format 16:9, 1920×1080, 30fps, 450 frame. Karakter, palet, framing, dan animasi digambar ulang secara mandiri.

Tiga shot: jatuh dengan pengukuran 200×, bangkit dan berjalan, lalu tetesan air sebagai ancaman. Dua transisi diagonal menghubungkan shot. Teks hanya “200×” dan “THIS?”. Tanpa subtitle. VO dipotong tepat 15 detik dengan fade 0,15 detik pada ujung cuplikan agar batas preview nyaman didengar; narasi lengkap tidak diringkas atau diganti.

## Teknologi

- `visual.js`: fungsi JavaScript deterministik yang menghasilkan SVG, pose, dan mekanisme transisi.
- `index.html`: komposisi HyperFrames dengan timeline GSAP, animasi masuk dan transisi; audio dikendalikan framework.
- `remotion/`: komposisi React/Remotion dari fungsi visual yang sama.
- `render.mjs`: render MP4 final dan frame review melalui Remotion.
- `DESIGN.md`: identitas visual dan timing.
- `assets/`: potongan VO, Fraunces 900, dan GSAP lokal.

Tidak menggunakan starter, kode ilustrasi, karakter, atau acuan gaya Bang Motion. Tidak ada permintaan aset eksternal.

## Menjalankan

Memerlukan Node.js 22+, FFmpeg, dan Chrome/Chromium.

```bash
npm ci
npm run check
npm run dev
npm run render:remotion
```

Untuk browser lokal, atur `REMOTION_BROWSER_EXECUTABLE` bagi Remotion dan `HYPERFRAMES_BROWSER_PATH` bagi HyperFrames. Remotion dapat mengelola browser sendiri jika variabel itu tidak disetel. Preview dengan audio menggunakan Studio HyperFrames, bukan membuka sumber HTML sebagai player mandiri.

## Validasi

Pemeriksaan HyperFrames mencakup lint, runtime, layout, motion dan kontras. Frame kunci, kontak tangan-air, scrubbing deterministik, font, dan metadata audio diperiksa di browser. MP4 akhir diperiksa resolusi, durasi, jumlah frame, decoding, dan kecocokan audio terhadap potongan VO.

## Lisensi

VO disediakan pengguna. Ilustrasi dibuat khusus. Fraunces menggunakan SIL Open Font License. HyperFrames, GSAP dan Remotion mengikuti lisensi paket masing-masing; lisensi yang disediakan paket disertakan.
