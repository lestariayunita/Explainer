# Independent preview — 15 seconds

## Style Prompt
A new macro cartoon explainer based on the opening of the same English VO. Three close-framed shots: an alarming fall, an unexpected recovery, and a looming water droplet. Designed independently with Remotion, HyperFrames and JavaScript; no Bang Motion starter, code, character, palette, or motion recipe. Editorial framing, expressive limbs, large foreground shapes, two diagonal cover transitions and a restrained glass reflection.

## Colors
- #16263B — midnight contours and suspense shots.
- #F5F0E5 — bone highlights and daylight recovery.
- #F26A3D — coral jacket and impact accent.
- #BDEC6D — lime scale accents and wipes.
- #60B6D0 — cool water and atmospheric details.

## Typography
Fraunces 900 for the single scale number and brief question. Its substantial, irregular serif shapes feel like a storybook scientific illustration. No subtitles, body copy, or caption rail.

## Timing
0–4.975s: falling hook, 200×. 4.975–10.05s: land, stand, walk. 10.05–15s: a familiar drop becomes ominous; THIS? appears near the end. Diagonal full-cover transitions start at 4.65s and 9.75s. The first 15 seconds of the supplied VO are used, with a 0.15s fade at the preview boundary. 1920×1080, 30fps, exactly 450 frames.

## What NOT to Do
No assets from the earlier animation. No repeated wide garden framing. No subtitles or paragraphs. No long empty title card. No random values or wall-clock animation. This is a preview excerpt, not a complete account of the science.
